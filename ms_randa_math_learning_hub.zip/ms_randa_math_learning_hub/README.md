# Ms Randa Math Learning Hub

A free, mobile-friendly static website for open-access Alberta Grade 10 Mathematics (Math 10C) learning.

## Preview locally
Open `index.html` in a web browser.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new **public** repository named `ms-randa-math-learning-hub`.
3. Upload `index.html` to the repository root.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

No paid hosting, database, or student login is required for this starter version.

## Important
- Quiz answers are checked in the student's browser; they are not stored or sent to the teacher.
- This is an independent supplementary resource, not an official Alberta Education site.
- Course content should be reviewed against the current school/program requirements before being used as a complete course.
